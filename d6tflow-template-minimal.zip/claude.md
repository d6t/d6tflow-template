# Claude Instructions: Working with d6tflow Workflows

## What is d6tflow?

**d6tflow** is a Python library for building data science workflows. It's built on top of **Luigi** (Spotify's workflow orchestration library) and designed specifically for data science and machine learning pipelines.

### Key Benefits
- **Dependency management**: Automatically runs tasks in the correct order
- **Caching**: Only re-runs tasks when inputs change
- **Parameter tracking**: Different parameters create different task instances
- **Data persistence**: Automatically saves/loads data between tasks
- **Reproducibility**: Complete lineage of data transformations

### When to Use d6tflow
- ✅ Multi-step data pipelines (data loading → cleaning → features → models → predictions)
- ✅ Machine learning workflows with dependencies between tasks
- ✅ Workflows that need to be re-run with different parameters
- ✅ Projects where you want automatic caching and incremental computation

---

## Core Concepts

### 1. Tasks

Tasks are the fundamental building blocks. Each task:
- Inherits from a d6tflow task class
- Has a `run()` method that does the work
- Can depend on other tasks
- Saves output automatically
- Is uniquely identified by its class name + parameters

```python
import d6tflow
import pandas as pd

class LoadData(d6tflow.tasks.TaskPqPandas):
    """
    Load raw data from CSV
    """

    def run(self):
        df = pd.read_csv('data.csv')
        self.save(df)  # Automatically saves as parquet
```

### 2. Task Types

d6tflow provides different task types for different output formats:

| Task Type | Output Format | Use Case |
|-----------|---------------|----------|
| `TaskPqPandas` | Parquet | DataFrames (default choice, fast) |
| `TaskCachePandas` | Pickle | DataFrames (legacy, slower) |
| `TaskCSVPandas` | CSV | DataFrames (human-readable) |
| `TaskExcelPandas` | Excel | DataFrames (for reports) |
| `TaskPickle` | Pickle | Any Python object (models, dicts, lists) |
| `TaskJson` | JSON | Dictionaries, simple data structures |
| `TaskAggregator` | None | Runs dependencies without saving output |

**Best Practice**: Use `TaskPqPandas` for DataFrames (fastest), `TaskPickle` for models/objects.

### 3. Dependencies

Tasks declare dependencies using the `@d6tflow.requires()` decorator:

```python
@d6tflow.requires(LoadData)
class CleanData(d6tflow.tasks.TaskPqPandas):
    """
    Clean the raw data
    """

    def run(self):
        df = self.input().load()  # Load from LoadData
        df_clean = df.dropna()
        self.save(df_clean)
```

**Multiple dependencies**:
```python
@d6tflow.requires(LoadData, LoadMetadata)
class MergeData(d6tflow.tasks.TaskPqPandas):
    def run(self):
        df_data, df_meta = self.inputLoad()  # Unpack multiple inputs
        df_merged = df_data.merge(df_meta, on='id')
        self.save(df_merged)
```

### 4. Parameters

Parameters make tasks dynamic and reusable. They affect task identity:

```python
class ProcessData(d6tflow.tasks.TaskPqPandas):
    # Parameters define task variants
    date = d6tflow.DateParameter()
    region = d6tflow.Parameter()
    threshold = d6tflow.IntParameter(default=100)

    def run(self):
        # Use parameters in processing
        df = self.input().load()
        df = df[df['region'] == self.region]
        df = df[df['value'] > self.threshold]
        self.save(df)
```

**Parameter Types**:
- `d6tflow.Parameter()` - String
- `d6tflow.IntParameter()` - Integer
- `d6tflow.FloatParameter()` - Float
- `d6tflow.BoolParameter()` - Boolean
- `d6tflow.DateParameter()` - Date
- `d6tflow.ListParameter()` - List
- `d6tflow.DictParameter()` - Dictionary

**Important**: Same class + same parameters = same task instance (cached). Different parameters = different task instance (separate cache).

### 5. Parameter Inheritance

Tasks automatically inherit parameters from their dependencies:

```python
class TaskA(d6tflow.tasks.TaskPqPandas):
    date = d6tflow.DateParameter()

    def run(self):
        # Use self.date
        pass

@d6tflow.requires(TaskA)
class TaskB(d6tflow.tasks.TaskPqPandas):
    # Automatically inherits 'date' parameter from TaskA

    def run(self):
        df = self.input().load()
        # self.date is available here too
        pass
```

**Non-significant parameters**: Use `significant=False` for parameters that don't affect task identity (e.g., environment flags):

```python
class MyTask(d6tflow.tasks.TaskPqPandas):
    date = d6tflow.DateParameter()  # Affects task identity
    verbose = d6tflow.BoolParameter(default=False, significant=False)  # Doesn't affect identity
```

---

## Working with Tasks

### Loading Data from Upstream Tasks

**Single input**:
```python
@d6tflow.requires(UpstreamTask)
class MyTask(d6tflow.tasks.TaskPqPandas):
    def run(self):
        df = self.input().load()
        # or
        df = self.inputLoad()
```

**Multiple inputs**:
```python
@d6tflow.requires(Task1, Task2, Task3)
class MyTask(d6tflow.tasks.TaskPqPandas):
    def run(self):
        df1, df2, df3 = self.inputLoad()
```

**Dynamic dependencies** (list of tasks):
```python
@d6tflow.requires({'data': LoadData, 'meta': LoadMetadata})
class MyTask(d6tflow.tasks.TaskPqPandas):
    def run(self):
        df_data = self.input()['data'].load()
        df_meta = self.input()['meta'].load()
```

### Saving Multiple Outputs

Some tasks need to save multiple DataFrames/objects:

```python
class SplitData(d6tflow.tasks.TaskPqPandas):
    persist = ['train', 'test', 'valid']  # Names for outputs

    def run(self):
        df = self.input().load()
        df_train = df.sample(frac=0.7)
        df_test = df.sample(frac=0.2)
        df_valid = df.sample(frac=0.1)

        # Save all three
        self.save([df_train, df_test, df_valid], from_list=True)

# Loading multiple outputs
@d6tflow.requires(SplitData)
class TrainModel(d6tflow.tasks.TaskPickle):
    def run(self):
        df_train, df_test, df_valid = self.inputLoad()
        # Or load specific output:
        # df_train = self.input().load(persist='train')
```

**Dictionary outputs**:
```python
class MyTask(d6tflow.tasks.TaskPqPandas):
    persists = ['data', 'metadata']  # Note: persists with 's'

    def run(self):
        result = {
            'data': df_main,
            'metadata': df_meta
        }
        self.save(result)

# Loading
@d6tflow.requires(MyTask)
class NextTask(d6tflow.tasks.TaskPqPandas):
    def run(self):
        data = self.inputLoad()
        df_main = data['data']
        df_meta = data['metadata']
```

### Saving Metadata (Models, Configs)

Use metadata for objects that don't fit standard formats (trained models, config dicts):

```python
class TrainModel(d6tflow.tasks.TaskPqPandas):
    def run(self):
        df_train = self.input().load()

        # Train model
        from sklearn.ensemble import RandomForestClassifier
        model = RandomForestClassifier()
        model.fit(df_train[features], df_train['target'])

        # Save predictions
        df_train['pred'] = model.predict(df_train[features])
        self.save(df_train)

        # Save model as metadata
        self.saveMeta({
            'model': model,
            'accuracy': 0.95,
            'features': features
        })

# Loading metadata
@d6tflow.requires(TrainModel)
class ApplyModel(d6tflow.tasks.TaskPqPandas):
    def run(self):
        df_test = self.input().load()
        meta = self.metaLoad()

        model = meta['model']
        features = meta['features']

        df_test['pred'] = model.predict(df_test[features])
        self.save(df_test)
```

**Loading metadata from specific upstream task**:
```python
@d6tflow.requires(TrainModel, LoadData)
class MyTask(d6tflow.tasks.TaskPqPandas):
    def run(self):
        # Load metadata from first dependency (TrainModel)
        meta = self.metaLoad(key=0)
        model = meta['model']

        # Load data from second dependency
        df = self.input()[1].load()
```

---

## Running Workflows

### Basic Workflow Execution

```python
import d6tflow

# Define your final task
class FinalTask(d6tflow.tasks.TaskPqPandas):
    # ... task definition ...
    pass

# Create workflow
flow = d6tflow.Workflow(FinalTask, params={'date': '2024-01-01'})

# Run the workflow
flow.run()

# Load output
result = flow.outputLoad()
```

### Workflow with Parameters

```python
params = {
    'date': '2024-01-01',
    'region': 'US',
    'threshold': 100
}

flow = d6tflow.Workflow(FinalTask, params=params)
flow.run()
```

### Checking Workflow Status

```python
# Preview what will run
flow.preview()

# Check if tasks are complete
flow.complete()  # Returns True if all tasks complete

# Show task graph
import luigi
luigi.build([FinalTask(date='2024-01-01')], local_scheduler=True)
```

### Forcing Re-runs (Reset)

d6tflow caches completed tasks. To force re-run:

```python
# Reset a specific task (and all downstream tasks)
flow.reset(TaskName)

# Reset without confirmation
flow.reset(TaskName, confirm=False)

# Reset entire workflow
flow.resetAll()
```

**When to reset**:
- Source data changed
- Task code changed
- Parameters changed (usually auto-detected)
- Want fresh results

### Loading Task Outputs

```python
# Load final task output
result = flow.outputLoad()

# Load specific task output
df = flow.outputLoad(IntermediateTask)

# Load specific persist
df_train = flow.outputLoad(SplitData, persist='train')

# Load metadata
meta = flow.metaLoad(TrainModel)
```

---

## Advanced Patterns

### Pattern 1: Dynamic Task Creation

Generate multiple task instances with different parameters:

```python
import d6tflow.utils

# Create parameter combinations
params_base = {'threshold': 100}
params_list = d6tflow.utils.params_generator_dictlist(
    {'date': ['2024-01-01', '2024-01-02', '2024-01-03']},
    params_base
)
# Result: [
#   {'date': '2024-01-01', 'threshold': 100},
#   {'date': '2024-01-02', 'threshold': 100},
#   {'date': '2024-01-03', 'threshold': 100}
# ]

# Run workflow for each parameter set
flow = d6tflow.WorkflowMulti(FinalTask, params_list)
flow.run()
```

### Pattern 2: Conditional Dependencies

Use `@d6tflow.requires()` with logic:

```python
class MyTask(d6tflow.tasks.TaskPqPandas):
    use_cache = d6tflow.BoolParameter()

    def requires(self):
        if self.use_cache:
            return CachedData()
        else:
            return FreshData()

    def run(self):
        df = self.input().load()
        # ... process ...
        self.save(df)
```

### Pattern 3: External Dependencies

Check if external files exist before running:

```python
import luigi

class LoadExternalData(d6tflow.tasks.TaskPqPandas):
    file_path = d6tflow.Parameter()

    def requires(self):
        # Ensure external file exists
        return luigi.LocalTarget(self.file_path)

    def run(self):
        df = pd.read_csv(self.file_path)
        self.save(df)
```

### Pattern 4: Workflow Orchestration Task

Create a task that just runs dependencies without saving output:

```python
@d6tflow.requires(Task1, Task2, Task3, Task4)
class RunAll(d6tflow.tasks.TaskAggregator):
    """
    Runs all tasks in the pipeline
    """
    pass

# Or with output
@d6tflow.requires(Task1, Task2, Task3)
class RunAll(d6tflow.tasks.TaskJson):
    def run(self):
        self.save({'status': 'complete', 'timestamp': datetime.now()})
```

### Pattern 5: Nested Workflows

Run sub-workflows within a task:

```python
class MasterTask(d6tflow.tasks.TaskPqPandas):
    def run(self):
        results = []

        for region in ['US', 'EU', 'ASIA']:
            # Create and run sub-workflow
            sub_flow = d6tflow.Workflow(
                ProcessRegion,
                params={'region': region}
            )
            sub_flow.run()

            # Load result
            df = sub_flow.outputLoad()
            results.append(df)

        # Combine results
        df_all = pd.concat(results)
        self.save(df_all)
```

### Pattern 6: Incremental Processing

Process only new data:

```python
class IncrementalTask(d6tflow.tasks.TaskPqPandas):
    date = d6tflow.DateParameter()

    def run(self):
        # Load previous results if they exist
        prev_date = self.date - timedelta(days=1)
        try:
            prev_task = IncrementalTask(date=prev_date)
            if prev_task.complete():
                df_prev = prev_task.output().load()
            else:
                df_prev = pd.DataFrame()
        except:
            df_prev = pd.DataFrame()

        # Process only current date
        df_new = pd.read_csv(f'data_{self.date}.csv')

        # Combine with previous
        df_all = pd.concat([df_prev, df_new])
        self.save(df_all)
```

---

## Configuration

### Environment-Based Configuration

```python
class MyTask(d6tflow.tasks.TaskPqPandas):
    env = d6tflow.Parameter(significant=False)  # 'dev' or 'prod'

    def run(self):
        if self.env == 'dev':
            # Use sample data
            df = pd.read_csv('sample.csv')
        else:
            # Use full data
            df = pd.read_csv('full.csv')

        self.save(df)

# Run in dev mode
flow = d6tflow.Workflow(MyTask, params={'env': 'dev'})
```

### Custom Task Directories

```python
class MyTask(d6tflow.tasks.TaskPqPandas):
    def output(self):
        # Custom output path
        return d6tflow.targets.PqPandas(
            path='/custom/path/output.parquet'
        )
```

---

## Best Practices

### 1. Task Design

✅ **Do**:
- Keep tasks focused on a single responsibility
- Use descriptive task names (verbs: Load, Clean, Transform, Train, Predict)
- Add docstrings explaining what the task does
- Use type hints for clarity
- Validate inputs and outputs with assertions

❌ **Don't**:
- Create monolithic tasks that do everything
- Use generic names like `Task1`, `Task2`
- Skip error handling
- Assume data shape/columns without validation

```python
# Good
class CalculateFeatures(d6tflow.tasks.TaskPqPandas):
    """
    Calculate rolling averages and momentum features

    Input: DataFrame with columns ['date', 'value']
    Output: DataFrame with additional columns ['ma_30', 'ma_90', 'momentum']
    """

    def run(self):
        df = self.input().load()

        # Validate input
        assert 'date' in df.columns, "Missing 'date' column"
        assert 'value' in df.columns, "Missing 'value' column"
        assert df.shape[0] > 0, "Empty DataFrame"

        # Calculate features
        df['ma_30'] = df['value'].rolling(30).mean()
        df['ma_90'] = df['value'].rolling(90).mean()
        df['momentum'] = df['value'].pct_change(30)

        # Validate output
        assert not df['ma_30'].isna().all(), "All ma_30 values are NaN"

        self.save(df)
```

### 2. Parameter Management

✅ **Do**:
- Define parameters at the top of the class
- Use appropriate parameter types
- Provide sensible defaults
- Use `significant=False` for non-data-affecting parameters
- Keep parameters in a separate config file/dict

❌ **Don't**:
- Hard-code values that should be parameters
- Use parameters for values that never change
- Create too many parameters (makes task identity complex)

```python
# Good - centralized parameters
params = {
    'date': '2024-01-01',
    'region': 'US',
    'model_type': 'rf',
    'n_estimators': 100,
    'test_size': 0.2
}

flow = d6tflow.Workflow(FinalTask, params=params)

# Bad - hard-coded values
class TrainModel(d6tflow.tasks.TaskPickle):
    def run(self):
        model = RandomForestClassifier(n_estimators=100)  # Should be parameter
        test_size = 0.2  # Should be parameter
```

### 3. Data Validation

✅ **Do**:
- Assert expected columns exist
- Check for null values where unexpected
- Validate data shapes
- Check value ranges
- Log warnings for anomalies


```python
class ValidatedTask(d6tflow.tasks.TaskPqPandas):
    def run(self):
        df = self.input().load()

        # Column checks
        required_cols = ['id', 'date', 'value']
        assert all(c in df.columns for c in required_cols), \
            f"Missing columns. Have: {df.columns.tolist()}, Need: {required_cols}"

        # Null checks
        assert df['id'].isna().sum() == 0, "Null IDs found"

        # Shape checks
        assert df.shape[0] > 0, "Empty DataFrame"
        assert df.shape[1] >= 3, "Too few columns"

        # Value range checks
        assert df['value'].min() >= 0, "Negative values found"

        # Duplicate checks
        assert not df.duplicated('id').any(), "Duplicate IDs found"

        self.save(df)
```

### 4. Error Handling

✅ **Do**:
- Use loguru for logging of errors

❌ **Don't**:
- Use try-except, if there is an error the pipeline can just fail natively

```python
class RobustTask(d6tflow.tasks.TaskPqPandas):
    def run(self):
        try:
            df = pd.read_csv(self.file_path)
        except FileNotFoundError:
            raise FileNotFoundError(
                f"Data file not found: {self.file_path}. "
                f"Please ensure data is downloaded first."
            )
        except pd.errors.EmptyDataError:
            raise ValueError(
                f"Data file is empty: {self.file_path}"
            )

        self.save(df)
```

### 5. Testing

✅ **Do**:
- Test tasks individually before running full pipeline
- Use small sample data for development
- Create test fixtures
- Validate outputs manually first time

```python
# Test individual task
def test_clean_data():
    # Create test input
    df_test = pd.DataFrame({'value': [1, 2, None, 4]})

    # Run task
    task = CleanData()
    # ... (setup input) ...
    task.run()

    # Validate output
    df_result = task.output().load()
    assert df_result['value'].isna().sum() == 0
    assert df_result.shape[0] == 3

# Test workflow
def test_workflow():
    params = {'date': '2024-01-01', 'env': 'test'}
    flow = d6tflow.Workflow(FinalTask, params=params)
    flow.resetAll(confirm=False)
    flow.run()
    assert flow.complete()
```

### 6. Documentation

✅ **Do**:
- Add docstrings to every task
- Document expected inputs/outputs
- Note any assumptions
- Explain complex logic
- Keep a workflow diagram/documentation

```python
class CalculateReturns(d6tflow.tasks.TaskPqPandas):
    """
    Calculate forward returns for each asset

    Input Requirements:
        - DataFrame with columns: ['date', 'asset_id', 'price']
        - Data sorted by ['asset_id', 'date']
        - No missing prices

    Output:
        - Same DataFrame with additional columns:
          - 'return_1d': 1-day forward return
          - 'return_5d': 5-day forward return
          - 'return_20d': 20-day forward return

    Parameters:
        - horizon_days: list of forward return horizons (default: [1, 5, 20])

    Notes:
        - Returns are calculated as (future_price - current_price) / current_price
        - Last N rows per asset will have NaN forward returns (no future data)
    """
    horizon_days = d6tflow.ListParameter(default=[1, 5, 20])

    def run(self):
        # ... implementation ...
        pass
```

---

## Common Patterns for Data Science

### Pattern: Train/Test Split

```python
class SplitData(d6tflow.tasks.TaskPqPandas):
    persist = ['train', 'test']
    test_size = d6tflow.FloatParameter(default=0.2)
    random_state = d6tflow.IntParameter(default=42)

    def run(self):
        df = self.input().load()

        from sklearn.model_selection import train_test_split
        df_train, df_test = train_test_split(
            df,
            test_size=self.test_size,
            random_state=self.random_state
        )

        self.save([df_train, df_test], from_list=True)
```

### Pattern: Feature Engineering

```python
@d6tflow.requires(CleanData)
class EngineerFeatures(d6tflow.tasks.TaskPqPandas):
    def run(self):
        df = self.input().load()

        # Time-based features
        df['hour'] = df['timestamp'].dt.hour
        df['day_of_week'] = df['timestamp'].dt.dayofweek

        # Lag features
        df['value_lag1'] = df.groupby('id')['value'].shift(1)
        df['value_lag7'] = df.groupby('id')['value'].shift(7)

        # Rolling features
        df['value_ma7'] = df.groupby('id')['value'].rolling(7).mean().reset_index(0, drop=True)
        df['value_ma30'] = df.groupby('id')['value'].rolling(30).mean().reset_index(0, drop=True)

        # Interaction features
        df['feature_interaction'] = df['feature1'] * df['feature2']

        self.save(df)
```

### Pattern: Model Training

```python
@d6tflow.requires(SplitData, EngineerFeatures)
class TrainModel(d6tflow.tasks.TaskPqPandas):
    persist = ['predictions', 'metrics']
    model_type = d6tflow.Parameter(default='rf')

    def run(self):
        df_train, df_test = self.input()[0].load(persist='train'), self.input()[0].load(persist='test')
        df_features = self.input()[1].load()

        # Prepare features
        feature_cols = [c for c in df_features.columns if c.startswith('feature_')]
        X_train = df_train[feature_cols]
        y_train = df_train['target']
        X_test = df_test[feature_cols]
        y_test = df_test['target']

        # Train model
        if self.model_type == 'rf':
            from sklearn.ensemble import RandomForestRegressor
            model = RandomForestRegressor(n_estimators=100, random_state=42)
        elif self.model_type == 'lgbm':
            import lightgbm as lgb
            model = lgb.LGBMRegressor(n_estimators=100, random_state=42)

        model.fit(X_train, y_train)

        # Predictions
        df_test['prediction'] = model.predict(X_test)

        # Metrics
        from sklearn.metrics import mean_squared_error, r2_score
        metrics = {
            'rmse': mean_squared_error(y_test, df_test['prediction'], squared=False),
            'r2': r2_score(y_test, df_test['prediction']),
            'n_features': len(feature_cols)
        }

        self.save([df_test, pd.DataFrame([metrics])], from_list=True)
        self.saveMeta({'model': model, 'features': feature_cols})
```

### Pattern: Model Evaluation

```python
@d6tflow.requires(TrainModel)
class EvaluateModel(d6tflow.tasks.TaskJson):
    def run(self):
        df_pred, df_metrics = self.inputLoad()

        # Calculate additional metrics
        from sklearn.metrics import mean_absolute_error
        mae = mean_absolute_error(df_pred['target'], df_pred['prediction'])

        results = {
            'rmse': df_metrics['rmse'].values[0],
            'r2': df_metrics['r2'].values[0],
            'mae': mae,
            'n_samples': len(df_pred)
        }

        self.save(results)
```

### Pattern: Cross-Validation

```python
@d6tflow.requires(EngineerFeatures)
class CrossValidate(d6tflow.tasks.TaskPickle):
    n_folds = d6tflow.IntParameter(default=5)

    def run(self):
        df = self.input().load()

        from sklearn.model_selection import cross_val_score
        from sklearn.ensemble import RandomForestRegressor

        feature_cols = [c for c in df.columns if c.startswith('feature_')]
        X = df[feature_cols]
        y = df['target']

        model = RandomForestRegressor(n_estimators=100, random_state=42)
        scores = cross_val_score(
            model, X, y,
            cv=self.n_folds,
            scoring='neg_root_mean_squared_error'
        )

        results = {
            'scores': -scores,  # Convert back to positive
            'mean': -scores.mean(),
            'std': scores.std()
        }

        self.save(results)
```

---

## Debugging d6tflow Workflows

### Problem: Task not running

**Cause**: Task is already complete (cached)

**Solution**:
```python
flow.reset(TaskName)  # Force re-run
flow.run()
```

### Problem: Parameters not affecting task

**Cause**: Parameter has `significant=False` or wrong parameter type

**Solution**:
```python
# Check parameter definition
class MyTask(d6tflow.tasks.TaskPqPandas):
    # Make sure significant=True (default)
    param = d6tflow.Parameter()  # Not: significant=False
```

### Problem: Cannot load multiple outputs

**Cause**: Mismatch between `persist` list and saved outputs

**Solution**:
```python
# Make sure persist matches save
class MyTask(d6tflow.tasks.TaskPqPandas):
    persist = ['a', 'b', 'c']  # Must match number of outputs

    def run(self):
        self.save([df_a, df_b, df_c], from_list=True)  # 3 outputs
```

### Problem: Metadata not loading

**Cause**: Metadata not saved, or loading from wrong task

**Solution**:
```python
# Ensure metadata was saved
class TaskA(d6tflow.tasks.TaskPqPandas):
    def run(self):
        self.save(df)
        self.saveMeta({'key': 'value'})  # Make sure this runs

# Load from correct task index
@d6tflow.requires(TaskA, TaskB)
class TaskC(d6tflow.tasks.TaskPqPandas):
    def run(self):
        meta = self.metaLoad(key=0)  # From TaskA (first dependency)
```

---

## Quick Reference

### Create a task
```python
class MyTask(d6tflow.tasks.TaskPqPandas):
    param = d6tflow.Parameter()

    def run(self):
        # Do work
        self.save(result)
```

### Add dependencies
```python
@d6tflow.requires(UpstreamTask)
class MyTask(d6tflow.tasks.TaskPqPandas):
    def run(self):
        df = self.input().load()
```

### Run workflow
```python
flow = d6tflow.Workflow(FinalTask, params={'param': 'value'})
flow.run()
result = flow.outputLoad()
```

### Force re-run
```python
flow.reset(TaskName)
flow.run()
```

### Multiple outputs
```python
class MyTask(d6tflow.tasks.TaskPqPandas):
    persist = ['a', 'b']

    def run(self):
        self.save([df_a, df_b], from_list=True)
```

### Save metadata
```python
self.saveMeta({'model': model, 'config': config})
```

### Load metadata
```python
meta = self.metaLoad()
model = meta['model']
```

---

## Project Structure

d6tflow projects typically follow a standard file organization that separates concerns and makes workflows easier to manage.

### Typical File Layout

```
project/
├── tasks.py           # Workflow task definitions
├── cfg.py             # Global configuration and settings
├── flow_params.py     # Workflow-specific parameters
├── flow.py            # Workflow instance definition
├── run.py             # Execute workflow tasks
├── visualize.py       # Use outputs for analysis (script)
├── visualize.ipynb    # Use outputs for analysis (notebook)
└── .creds.yaml        # Protected credentials (NOT committed to git)
```

### Key Concepts

This structure follows a **separation of concerns** pattern:

1. **Configuration Layer** (`cfg.py` + `flow_params.py`)
   - `cfg.py`: Global settings (environment, dates, credentials)
   - `flow_params.py`: Workflow-specific task parameters

2. **Definition Layer** (`tasks.py` + `flow.py`)
   - `tasks.py`: Define what each task does
   - `flow.py`: Define which tasks to run with which parameters

3. **Execution Layer** (`run.py`)
   - `run.py`: Execute the workflow

4. **Analysis Layer** (`visualize.py` + `visualize.ipynb`)
   - Load and analyze workflow outputs

**The key advantage**: Define your workflow once in `flow.py`, then import it everywhere (`from flow import flow`). This ensures consistency across execution, analysis, and notebooks.

### File Descriptions

#### `tasks.py` - Workflow Tasks

Contains all your d6tflow task definitions. This is where you define the workflow pipeline.

```python
import d6tflow
import pandas as pd
import cfg

class GetData(d6tflow.tasks.TaskPqPandas):
    """
    Load raw data
    """
    def run(self):
        df = pd.DataFrame({'a': range(10)})
        self.save(df)

@d6tflow.requires(GetData)
class Process(d6tflow.tasks.TaskPqPandas):
    """
    Process the raw data
    """
    optional = d6tflow.BoolParameter(default=False)

    def run(self):
        df = self.input().load()
        if self.optional:
            df = df * 2
        self.save(df)
```

**Best Practices**:
- One file for simple projects, can split into multiple files for complex projects (e.g., `tasks_etl.py`, `tasks_models.py`)
- Keep tasks focused and well-documented
- Import `cfg` to access centralized configuration

#### `cfg.py` - Global Configuration

Central configuration file for global settings, environment flags, and credentials. This file contains configuration that applies across all workflows.

```python
# Environment setting
env = None  # Could be 'dev' or 'prod'
do_preprocess = True

# Date parameters
import datetime
dt_start = datetime.date(2010, 1, 1)
dt_end = datetime.date(2020, 1, 1)

# Load protected credentials (optional)
try:
    import yaml
    with open('.creds.yaml') as fh:
        cfg_yaml = yaml.safe_load(fh)
except:
    pass
```

**Best Practices**:
- Keep global settings here (environment, dates, feature flags)
- Use for configuration that applies to all workflows
- Handle missing credentials gracefully
- Keep workflow-specific parameters separate (see `flow_params.py`)

#### `flow_params.py` - Workflow Parameters

Contains parameters specific to your workflow tasks. This separates workflow logic from global configuration.

```python
import cfg

params = dict()

# Example parameters (commented out)
'''
# examples
params['env'] = cfg.env
params['transformx'] = 'zscore'
params['transformy'] = 'rank'
params['features_ts'] = False
# params['model'] = 'rf'
params['model'] = 'lgbm'
# params['regularize'] = False
params['regularize'] = True
'''
```

**Best Practices**:
- Define all task parameters here
- Can reference values from `cfg.py` (e.g., `params['env'] = cfg.env`)
- Comment/uncomment different parameter combinations for experiments
- Keep this separate from `cfg.py` for clarity

**Why separate `cfg.py` and `flow_params.py`?**
- `cfg.py`: Global settings (environment, credentials, dates)
- `flow_params.py`: Workflow-specific task parameters
- Makes it easier to manage multiple workflows or parameter sets

#### `flow.py` - Workflow Instance

Defines the workflow instance that can be imported and used by other scripts.

```python
import d6tflow

import cfg
import tasks
from flow_params import params

# Select which task to run
# task = tasks.GetData
task = tasks.Process

# Create workflow instance
flow = d6tflow.Workflow(task=task, params=params, env=cfg.env)
```

**Best Practices**:
- Define workflow instance once, import everywhere
- Makes it easy to switch between different final tasks
- Centralizes workflow configuration
- Other scripts just need `from flow import flow`

**Why use `flow.py`?**
- **DRY principle**: Define workflow once, use in multiple places
- **Consistency**: Same workflow instance in `run.py`, `visualize.py`, and `visualize.ipynb`
- **Easy switching**: Change `task` variable to run different workflows

#### `run.py` - Execute Workflow

Main script to execute your workflow. Run this to trigger the pipeline.

```python
import d6tflow
import cfg, tasks

from flow import flow

# Optional: Reset tasks to force re-run
# flow.reset(tasks.GetData)

# Preview what will run
flow.preview()

# Execute workflow
flow.run()
```

**Usage**:
```bash
python run.py
```

**Best Practices**:
- Keep this file simple - just import flow and run
- Use `flow.preview()` to check what will run before execution
- Comment out `flow.reset()` (uncomment when you need to force re-run)
- Workflow configuration is in `flow.py`, so this stays clean
- Can create multiple run scripts for different workflows (e.g., `run_training.py`, `run_prediction.py`)

#### `visualize.py` - Analysis Script

Use workflow outputs for further analysis, reporting, or visualization. Organized as functions for reusability.

```python
import d6tflow
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

import tasks
from flow import flow

def plot_data():
    """
    Load and plot workflow outputs
    """
    df_data = flow.outputLoad(tasks.GetData)
    # Create your plots here
    # df_data.plot()
    # plt.savefig('output.png')

# Execute
plot_data()
```

**Best Practices**:
- Import `flow` from `flow.py` for consistency
- Use `flow.outputLoad(TaskName)` to load specific task outputs
- Organize analysis into functions for reusability
- Don't re-run workflow here, just load and analyze outputs
- Export results (plots, tables, reports)

#### `visualize.ipynb` - Jupyter Notebook

Interactive notebook for exploratory data analysis using workflow outputs.

```python
# Cell 1: Imports
import d6tflow
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

import tasks
from flow import flow

# Cell 2: Optionally run workflow (usually commented out)
# flow.run()

# Cell 3: Load data from tasks
df_data = flow.outputLoad(tasks.GetData)

# Cell 4: Visualize
df_data.plot.bar()
```

**Best Practices**:
- Import `flow` from `flow.py` for consistency with other scripts
- Use `flow.outputLoad(TaskName)` to load outputs
- Comment out `flow.run()` - typically run workflow via `run.py` first
- Use for interactive exploration and experimentation
- Convert production-ready analysis to `visualize.py` for reproducibility
- Each cell should be relatively independent for easy re-running

#### `.creds.yaml` - Protected Credentials (Optional)

Store sensitive credentials that should NOT be committed to version control.

```yaml
# .creds.yaml
api_key: "your-api-key-here"
db_user: "username"
db_password: "password"
aws_access_key: "AKIAIOSFODNN7EXAMPLE"
aws_secret_key: "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
```

**IMPORTANT**:
- Add `.creds.yaml` to `.gitignore` immediately
- Never commit credentials to git
- Provide `.creds.yaml.example` template for team members
- Use environment variables as alternative

**Loading in `cfg.py`**:
```python
import yaml

try:
    with open('.creds.yaml') as fh:
        cfg_yaml = yaml.safe_load(fh)
except FileNotFoundError:
    cfg_yaml = {}  # Provide defaults or raise error
```

**Using in tasks**:
```python
import cfg

class DownloadData(d6tflow.tasks.TaskPqPandas):
    def run(self):
        api_key = cfg.cfg_yaml.get('api_key')
        # Use api_key to fetch data
```

### How the Files Work Together

Understanding the flow between files is important for effective d6tflow project organization:

```
┌─────────────────────────────────────────────────────────────┐
│                    Project File Flow                         │
└─────────────────────────────────────────────────────────────┘

1. cfg.py (Global Config)
   ↓
2. flow_params.py (imports cfg)
   ↓
3. tasks.py (imports cfg)
   ↓
4. flow.py (imports cfg, tasks, flow_params)
   ↓
5. run.py, visualize.py, visualize.ipynb (all import flow)
```

**Execution Flow**:

1. **Define global settings** (`cfg.py`)
   - Environment flags, dates, credentials

2. **Define workflow parameters** (`flow_params.py`)
   - Task-specific parameters
   - Can reference `cfg.py` values

3. **Define tasks** (`tasks.py`)
   - Workflow task classes
   - Can reference `cfg.py` for global settings

4. **Create workflow instance** (`flow.py`)
   - Combines tasks + parameters + config
   - Single source of truth for the workflow

5. **Use workflow** (everywhere else)
   - `run.py`: Execute workflow
   - `visualize.py`: Analyze outputs
   - `visualize.ipynb`: Interactive analysis
   - All import the same `flow` instance

**Benefits of this structure**:
- **Consistency**: Same workflow instance everywhere
- **DRY**: Define workflow once, use in multiple places
- **Flexibility**: Easy to switch tasks or parameters
- **Clarity**: Separation of concerns (config vs. params vs. logic)

**Example workflow**:

```python
# 1. Edit parameters in flow_params.py
params['model'] = 'lgbm'
params['regularize'] = True

# 2. Switch task in flow.py if needed
task = tasks.Process  # or tasks.GetData

# 3. Run workflow
python run.py

# 4. Analyze in notebook
# Open visualize.ipynb and run cells
# Or run: python visualize.py
```

### Alternative Structures

#### Large Projects with Multiple Modules

```
project/
├── tasks/
│   ├── __init__.py
│   ├── etl.py          # ETL tasks
│   ├── features.py     # Feature engineering tasks
│   └── models.py       # Model training tasks
├── cfg.py
├── run.py
├── visualize.py
└── utils/
    ├── __init__.py
    ├── data_validation.py
    └── plotting.py
```

#### Multiple Workflows

```
project/
├── tasks.py
├── cfg.py
├── flow_params_train.py    # Training parameters
├── flow_params_predict.py  # Prediction parameters
├── flow_train.py           # Training workflow
├── flow_predict.py         # Prediction workflow
├── run_train.py            # Run training pipeline
├── run_predict.py          # Run prediction pipeline
└── visualize_models.py
```

**Using multiple workflows**:

```python
# flow_train.py
from flow_params_train import params
task = tasks.TrainModel
flow = d6tflow.Workflow(task=task, params=params)

# flow_predict.py
from flow_params_predict import params
task = tasks.MakePredictions
flow = d6tflow.Workflow(task=task, params=params)

# run_train.py
from flow_train import flow
flow.run()

# run_predict.py
from flow_predict import flow
flow.run()
```

### Version Control Best Practices

**Always commit**:
- `tasks.py` - Task definitions
- `cfg.py` - Global configuration
- `flow_params.py` - Workflow parameters
- `flow.py` - Workflow instance
- `run.py` - Execution script
- `visualize.py` - Analysis script
- `visualize.ipynb` - Analysis notebook
- `.creds.yaml.example` - Credentials template with dummy values

**Never commit**:
- `.creds.yaml` - Actual credentials
- `data/` - Raw data directory (can be large)
- Generated outputs/plots
- d6tflow cache files

**Example `.gitignore`**:
```gitignore
# Credentials
.creds.yaml
*.key
*.pem

# Data
data/
*.csv
*.parquet

# d6tflow cache
.d6tflow/

# Python
__pycache__/
*.pyc
.ipynb_checkpoints/

# Outputs
outputs/
plots/
*.png
*.pdf
```

---

## Additional Resources

- **Official docs**: https://d6tflow.readthedocs.io/
- **GitHub**: https://github.com/d6t/d6tflow
- **Luigi docs**: https://luigi.readthedocs.io/ (underlying framework)

---

## Summary

d6tflow is powerful for building reproducible, cacheable data science workflows:

1. **Tasks** are building blocks (classes with `run()` method)
2. **Dependencies** are declared with `@d6tflow.requires()`
3. **Parameters** make tasks dynamic and create task variants
4. **Automatic caching** prevents re-running completed tasks
5. **Multiple outputs** via `persist` attribute
6. **Metadata** for saving models and configs

**When to use**: Multi-step pipelines, ML workflows, reproducible research
**When not to use**: Simple scripts, real-time systems, single-step processes

The key is to break your workflow into logical, reusable tasks with clear dependencies!
