import d6tflow
import cfg, tasks
import visualize

params = {}
task_ = tasks.Process(**params)
flow = d6tflow.Workflow()
flow.preview(task_)
flow.run(task_)
