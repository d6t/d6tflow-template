import d6tflow
import cfg, tasks
import visualize

params = {}
task_ = tasks.Process
flow = d6tflow.Workflow(**params)
flow.preview(task_)
flow.run(task_)
