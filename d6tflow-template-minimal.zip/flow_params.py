import cfg

params=dict()

'''
# examples
params['env']=cfg.env
params['transformx']='zscore'
params['transformy']='rank'
params['features_ts']=False
# params['model']='rf'
params['model']='lgbm'
# params['regularize']=False
params['regularize']=True
'''