import d6tflow
import cfg, tasks


from flow import flow

# flow.reset(tasks.GetData)
flow.preview()
flow.run()

